import React from "react";
import styled from "styled-components";

const Logo = styled.div`

`;

const Logos = ({}) => {
  return <Logo>
   <img src="/Logo.svg"></img>
 </Logo>

}

export default Logos;
