import React from 'react';
import Searchbar from '../comps/Searchbar'; 

export default {
    title: 'Inputs/SearchBar',
    component: Searchbar
}; 

export const Searchcomp = () => <Searchbar/>;