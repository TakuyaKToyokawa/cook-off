import React from 'react';
import InputDate from '../comps/InputDate';

export default {
  title: 'Inputs/InputDate',
  component: InputDate,
};

export const BasicInputDate = () => <InputDate />;
