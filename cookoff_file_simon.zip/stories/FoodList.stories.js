import React from 'react';
import FoodList from '../comps/FoodList';

export default {
  title: 'Events/FoodList',
  component: FoodList,
};

export const BaseFoodList = () => <FoodList/>;