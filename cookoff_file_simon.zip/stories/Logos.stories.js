import React from 'react';
import Logos from '../comps/Logos';

export default {
  title: 'General/Logos',
  component: Logos,
};

export const BasicLogos = () => <Logos/>;