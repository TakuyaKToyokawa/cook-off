import React from 'react';
import RecipePost from '../comps/RecipePost';

export default {
  title: 'Recipe/RecipePost',
  component: RecipePost,
};

export const BasicRecipePost = () => <RecipePost />;
