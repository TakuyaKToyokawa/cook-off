import React from 'react';
import OnOffInput from '../comps/OnOffInput';

export default {
  title: 'Inputs/OnOffInput',
  component: OnOffInput,
};

export const Active = () => <OnOffInput/>;
